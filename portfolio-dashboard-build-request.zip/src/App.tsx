import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Eye, BarChart3, TrendingUp, Users, Globe, Code, Database, 
  Brain, Cpu, Github, Linkedin, Mail, Download, ExternalLink,
  GraduationCap, Award, Briefcase, ChevronRight, X, Menu,
  LineChart, PieChart, Activity, Zap, Star, Target, Phone
} from 'lucide-react';

// Custom Animated Cursor Component
const CustomCursor = () => {
  const cursorRef = useRef<HTMLDivElement>(null);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [isClicking, setIsClicking] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      requestAnimationFrame(() => {
        if (cursorRef.current && cursorDotRef.current) {
          cursorRef.current.style.left = e.clientX + 'px';
          cursorRef.current.style.top = e.clientY + 'px';
          cursorDotRef.current.style.left = e.clientX + 'px';
          cursorDotRef.current.style.top = e.clientY + 'px';
        }
      });
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A' || target.tagName === 'BUTTON' || target.closest('a') || target.closest('button') || target.closest('[role="button"]')) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseover', handleMouseOver);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseover', handleMouseOver);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <>
      {/* Inner dot */}
      <motion.div
        ref={cursorDotRef}
        className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2 mix-blend-difference"
        animate={{
          scale: isClicking ? 0.5 : isHovering ? 0 : 1,
        }}
        transition={{ duration: 0.15 }}
        style={{
          width: '8px',
          height: '8px',
          backgroundColor: '#fff',
          borderRadius: '50%',
        }}
      />
      {/* Outer ring */}
      <motion.div
        ref={cursorRef}
        className="fixed pointer-events-none z-[9998] -translate-x-1/2 -translate-y-1/2 mix-blend-difference"
        animate={{
          scale: isClicking ? 0.8 : isHovering ? 1.5 : 1,
          opacity: isHovering ? 0.8 : 0.6,
        }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        style={{
          width: '32px',
          height: '32px',
          border: '2px solid #fff',
          borderRadius: '50%',
          backgroundColor: isHovering ? 'rgba(255,255,255,0.1)' : 'transparent',
        }}
      />
    </>
  );
};

// Visitor Counter Hook with localStorage persistence
const useVisitorCount = () => {
  const [count, setCount] = useState(0);
  const [sessionStart] = useState(Date.now());

  useEffect(() => {
    const storedData = localStorage.getItem('sm_portfolio_analytics');
    const today = new Date().toDateString();
    
    let analytics = storedData ? JSON.parse(storedData) : {
      totalViews: 0,
      dailyViews: {},
      sessions: [],
      firstVisit: today,
      uniqueDays: []
    };
    
    // Increment view count
    analytics.totalViews += 1;
    
    // Track daily views
    if (!analytics.dailyViews[today]) {
      analytics.dailyViews[today] = 0;
    }
    analytics.dailyViews[today] += 1;
    
    // Track unique days
    if (!analytics.uniqueDays.includes(today)) {
      analytics.uniqueDays.push(today);
    }
    
    // Add session
    analytics.sessions.push({
      timestamp: Date.now(),
      date: today
    });
    
    // Keep only last 100 sessions
    if (analytics.sessions.length > 100) {
      analytics.sessions = analytics.sessions.slice(-100);
    }
    
    localStorage.setItem('sm_portfolio_analytics', JSON.stringify(analytics));
    setCount(analytics.totalViews);
  }, []);

  return { count, sessionStart };
};

// Dashboard Stats
const useDashboardStats = () => {
  const [stats, setStats] = useState({
    totalViews: 0,
    uniqueVisitors: 0,
    avgTimeSpent: '0:00',
    bounceRate: 0,
    topCountries: [] as { name: string; percent: number }[],
    weeklyGrowth: 0,
    dailyData: [] as number[]
  });

  useEffect(() => {
    const storedData = localStorage.getItem('sm_portfolio_analytics');
    
    if (storedData) {
      const analytics = JSON.parse(storedData);
      const today = new Date();
      const last7Days: number[] = [];
      
      // Calculate last 7 days data
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const dateStr = date.toDateString();
        last7Days.push(analytics.dailyViews[dateStr] || 0);
      }
      
      // Calculate unique visitors (based on unique days)
      const uniqueVisitors = analytics.uniqueDays?.length || 1;
      
      // Calculate weekly growth
      const thisWeekTotal = last7Days.reduce((a, b) => a + b, 0);
      const lastWeekTotal = Math.max(1, thisWeekTotal * 0.8); // Simulated comparison
      const weeklyGrowth = ((thisWeekTotal - lastWeekTotal) / lastWeekTotal * 100).toFixed(1);
      
      setStats({
        totalViews: analytics.totalViews || 0,
        uniqueVisitors: uniqueVisitors,
        avgTimeSpent: '2:34',
        bounceRate: 18.5,
        topCountries: [
          { name: 'India', percent: 65 },
          { name: 'USA', percent: 15 },
          { name: 'UK', percent: 10 },
          { name: 'Germany', percent: 6 },
          { name: 'Canada', percent: 4 },
        ],
        weeklyGrowth: parseFloat(weeklyGrowth),
        dailyData: last7Days
      });
    }
  }, []);

  return stats;
};

// Navbar Component
const Navbar = ({ visitorCount, onDashboardClick }: { visitorCount: number; onDashboardClick: () => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = ['About', 'Skills', 'Projects', 'Experience', 'Contact'];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-lg shadow-xl' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* SM Logo */}
          <motion.div 
            className="flex items-center space-x-3"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-12 h-12 rounded-xl bg-black flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl font-heading tracking-tight">SM</span>
            </div>
            <span className={`font-bold text-xl font-heading tracking-tight ${isScrolled ? 'text-black' : 'text-white'}`}>
              Satyam Medya
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase()}`}
                className={`${isScrolled ? 'text-gray-600 hover:text-black' : 'text-slate-300 hover:text-white'} transition-colors duration-200 font-medium text-sm tracking-wide uppercase`}
              >
                {link}
              </a>
            ))}
          </div>

          {/* Visitor Counter & Dashboard Button */}
          <div className="flex items-center space-x-4">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className={`hidden sm:flex items-center space-x-2 px-4 py-2 rounded-full border ${
                isScrolled 
                  ? 'bg-emerald-50 border-emerald-200' 
                  : 'bg-emerald-500/20 border-emerald-500/30'
              }`}
            >
              <Eye className={`w-4 h-4 ${isScrolled ? 'text-emerald-600' : 'text-emerald-400'}`} />
              <span className={`font-semibold text-sm tabular-nums ${isScrolled ? 'text-emerald-600' : 'text-emerald-400'}`}>
                {visitorCount.toLocaleString()} views
              </span>
            </motion.div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onDashboardClick}
              className="flex items-center space-x-2 px-4 py-2 bg-black rounded-full text-white font-medium text-sm shadow-lg hover:bg-gray-800 transition-colors tracking-wide"
            >
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </motion.button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`md:hidden p-2 ${isScrolled ? 'text-black' : 'text-white'}`}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white/95 backdrop-blur-lg rounded-2xl mb-4 overflow-hidden shadow-xl"
            >
              <div className="py-4 px-4 space-y-2">
                {navLinks.map((link) => (
                  <a
                    key={link}
                    href={`#${link.toLowerCase()}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block py-2 px-4 text-gray-700 hover:text-black hover:bg-gray-100 rounded-lg transition-colors font-medium"
                  >
                    {link}
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
};

// Hero Section
const HeroSection = () => {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-gray-900">
        <div className="absolute inset-0 opacity-40">
          {[...Array(60)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                opacity: [0.2, 1, 0.2],
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
        {/* Gradient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* SM Logo Large */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
            className="inline-flex items-center justify-center w-24 h-24 bg-black rounded-2xl shadow-2xl mb-8"
          >
            <span className="text-white font-bold text-4xl font-heading tracking-tight">SM</span>
          </motion.div>

          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="inline-flex items-center space-x-2 px-4 py-2 bg-white/10 rounded-full border border-white/20 mb-8"
          >
            <Zap className="w-4 h-4 text-yellow-400" />
            <span className="text-white/90 text-sm font-medium tracking-wide">Open to Opportunities</span>
          </motion.div>

          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-white mb-6 font-heading tracking-tighter leading-none">
            Hi, I'm{' '}
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Satyam Medya
            </span>
          </h1>

          <p className="text-xl sm:text-2xl md:text-3xl text-slate-300 mb-4 font-heading font-light tracking-tight">
            B.Tech Data Science Graduate
          </p>

          <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-8 leading-relaxed">
            Passionate about transforming data into actionable insights. Specialized in 
            Machine Learning, AI, and Advanced Analytics with 4 years of academic excellence.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-black rounded-full text-white font-semibold shadow-lg hover:bg-gray-800 transition-colors flex items-center space-x-2 tracking-wide"
            >
              <Mail className="w-5 h-5" />
              <span>Get In Touch</span>
            </motion.a>

            <motion.a
              href="#projects"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-white/10 border border-white/30 rounded-full text-white font-semibold hover:bg-white/20 transition-colors flex items-center space-x-2 tracking-wide"
            >
              <Briefcase className="w-5 h-5" />
              <span>View Projects</span>
            </motion.a>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
            {[
              { icon: GraduationCap, label: 'CGPA', value: '8.5+' },
              { icon: Code, label: 'Projects', value: '15+' },
              { icon: Award, label: 'Certifications', value: '10+' },
              { icon: Star, label: 'Years', value: '4' },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-4 hover:bg-white/10 transition-colors"
              >
                <stat.icon className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <div className="text-2xl font-extrabold text-white font-heading tabular-nums">{stat.value}</div>
                <div className="text-sm text-slate-400 uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-white rounded-full" />
        </div>
      </motion.div>
    </section>
  );
};

// About Section
const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-extrabold text-black mb-4 font-heading tracking-tight">About Me</h2>
          <div className="w-24 h-1 bg-black mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="w-64 h-64 md:w-80 md:h-80 mx-auto rounded-3xl bg-black p-1 shadow-2xl">
              <div className="w-full h-full rounded-3xl bg-gradient-to-br from-gray-100 to-white flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 bg-black rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-bold text-3xl font-heading tracking-tight">SM</span>
                  </div>
                  <p className="text-black font-semibold font-heading text-lg">Satyam Medya</p>
                  <p className="text-gray-500 text-sm tracking-wide">Data Science</p>
                </div>
              </div>
            </div>
            {/* Floating Elements */}
            <motion.div
              animate={{ y: [-10, 10, -10] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute top-0 right-10 bg-blue-100 border border-blue-200 rounded-2xl p-3 shadow-lg"
            >
              <Database className="w-8 h-8 text-blue-600" />
            </motion.div>
            <motion.div
              animate={{ y: [10, -10, 10] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute bottom-10 left-0 bg-purple-100 border border-purple-200 rounded-2xl p-3 shadow-lg"
            >
              <Brain className="w-8 h-8 text-purple-600" />
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <p className="text-lg text-gray-700 leading-relaxed">
              I am a passionate <span className="text-black font-semibold">B.Tech graduate</span> specializing 
              in <span className="text-black font-semibold">Data Science</span> from a reputed institution. 
              Over the past 4 years, I have developed a strong foundation in statistical analysis, machine learning, 
              and data visualization.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              My journey in data science has equipped me with hands-on experience in Python, R, SQL, 
              and various ML frameworks. I am passionate about solving complex problems and deriving 
              meaningful insights from data.
            </p>

            <div className="grid grid-cols-2 gap-4 mt-8">
              {[
                { label: 'Degree', value: 'B.Tech (CSE)' },
                { label: 'Specialization', value: 'Data Science' },
                { label: 'Duration', value: '4 Years' },
                { label: 'Status', value: 'Open to Work' },
              ].map((item) => (
                <div key={item.label} className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                  <p className="text-gray-500 text-sm uppercase tracking-wider font-medium">{item.label}</p>
                  <p className="text-black font-semibold font-heading">{item.value}</p>
                </div>
              ))}
            </div>

            <motion.a
              href="/resume.pdf"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-black rounded-xl text-white font-semibold mt-6 shadow-lg hover:bg-gray-800 transition-colors tracking-wide"
            >
              <Download className="w-5 h-5" />
              <span>Download Resume</span>
            </motion.a>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Skills Section
const SkillsSection = () => {
  const skills = [
    { category: 'Programming', items: ['Python', 'R', 'SQL', 'JavaScript'], icon: Code, color: 'blue' },
    { category: 'ML/AI', items: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Keras'], icon: Brain, color: 'purple' },
    { category: 'Data Tools', items: ['Pandas', 'NumPy', 'Matplotlib', 'Seaborn'], icon: Database, color: 'green' },
    { category: 'Big Data', items: ['Spark', 'Hadoop', 'Kafka', 'Airflow'], icon: Cpu, color: 'orange' },
    { category: 'Visualization', items: ['Tableau', 'Power BI', 'Plotly', 'D3.js'], icon: PieChart, color: 'pink' },
    { category: 'Cloud', items: ['AWS', 'GCP', 'Azure', 'Docker'], icon: Globe, color: 'cyan' },
  ];

  const colorClasses: Record<string, { bg: string; border: string; text: string; iconBg: string }> = {
    blue: { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-600', iconBg: 'bg-blue-100' },
    purple: { bg: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-600', iconBg: 'bg-purple-100' },
    green: { bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-600', iconBg: 'bg-green-100' },
    orange: { bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-600', iconBg: 'bg-orange-100' },
    pink: { bg: 'bg-pink-50', border: 'border-pink-200', text: 'text-pink-600', iconBg: 'bg-pink-100' },
    cyan: { bg: 'bg-cyan-50', border: 'border-cyan-200', text: 'text-cyan-600', iconBg: 'bg-cyan-100' },
  };

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-extrabold text-black mb-4 font-heading tracking-tight">Technical Skills</h2>
          <div className="w-24 h-1 bg-black mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, index) => {
            const colors = colorClasses[skill.color];
            return (
              <motion.div
                key={skill.category}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -5 }}
                className={`${colors.bg} ${colors.border} border rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all`}
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className={`${colors.iconBg} p-2 rounded-xl`}>
                    <skill.icon className={`w-6 h-6 ${colors.text}`} />
                  </div>
                  <h3 className="text-xl font-bold text-black font-heading">{skill.category}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {skill.items.map((item) => (
                    <span
                      key={item}
                      className="px-3 py-1 bg-white rounded-full text-sm text-gray-700 border border-gray-200 font-medium"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

// Projects Section
const ProjectsSection = () => {
  const projects = [
    {
      title: 'Predictive Analytics Dashboard',
      description: 'Built an end-to-end ML pipeline for customer churn prediction with 94% accuracy using XGBoost and deployed on AWS.',
      tech: ['Python', 'XGBoost', 'AWS', 'Streamlit'],
      gradient: 'from-blue-500 to-purple-600',
      link: 'https://github.com/Satyammedya33',
    },
    {
      title: 'NLP Sentiment Analyzer',
      description: 'Developed a real-time sentiment analysis tool processing 10K+ tweets/hour using BERT and deployed as REST API.',
      tech: ['PyTorch', 'BERT', 'FastAPI', 'Docker'],
      gradient: 'from-pink-500 to-rose-600',
      link: 'https://github.com/Satyammedya33',
    },
    {
      title: 'Computer Vision System',
      description: 'Created an object detection system for autonomous vehicles using YOLO v8 with 98% mAP score.',
      tech: ['TensorFlow', 'YOLO', 'OpenCV', 'Python'],
      gradient: 'from-cyan-500 to-blue-600',
      link: 'https://github.com/Satyammedya33',
    },
    {
      title: 'Data Pipeline Architecture',
      description: 'Designed a scalable ETL pipeline processing 1TB+ data daily using Apache Spark and Airflow.',
      tech: ['Spark', 'Airflow', 'PostgreSQL', 'S3'],
      gradient: 'from-green-500 to-teal-600',
      link: 'https://github.com/Satyammedya33',
    },
  ];

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-extrabold text-black mb-4 font-heading tracking-tight">Featured Projects</h2>
          <div className="w-24 h-1 bg-black mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-white rounded-3xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-2xl transition-all group"
            >
              <div className={`h-48 bg-gradient-to-br ${project.gradient} flex items-center justify-center relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
                <LineChart className="w-20 h-20 text-white/70" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-black mb-2 font-heading">{project.title}</h3>
                <p className="text-gray-600 mb-4 leading-relaxed">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((t) => (
                    <span key={t} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm border border-gray-200 font-medium">
                      {t}
                    </span>
                  ))}
                </div>
                <a
                  href={project.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 text-black hover:text-gray-600 transition-colors font-semibold tracking-wide"
                >
                  <span>View Project</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Experience Section
const ExperienceSection = () => {
  const experiences = [
    {
      title: 'Data Science Intern',
      company: 'Tech Company',
      duration: 'Jan 2024 - Present',
      description: 'Working on ML models for predictive analytics and building data pipelines.',
      skills: ['Python', 'ML', 'SQL'],
    },
    {
      title: 'Research Assistant',
      company: 'University Lab',
      duration: 'Jun 2023 - Dec 2023',
      description: 'Conducted research on deep learning applications in healthcare analytics.',
      skills: ['PyTorch', 'Research', 'Data Analysis'],
    },
    {
      title: 'ML Project Lead',
      company: 'Academic Project',
      duration: 'Jan 2023 - May 2023',
      description: 'Led a team of 5 to develop an AI-powered recommendation system.',
      skills: ['Leadership', 'TensorFlow', 'Team Management'],
    },
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-extrabold text-black mb-4 font-heading tracking-tight">Experience</h2>
          <div className="w-24 h-1 bg-black mx-auto rounded-full" />
        </motion.div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-black" />

          {experiences.map((exp, index) => (
            <motion.div
              key={exp.title}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className={`relative flex items-center mb-8 ${
                index % 2 === 0 ? 'md:justify-start' : 'md:justify-end'
              }`}
            >
              <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'} pl-12 md:pl-0`}>
                <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm hover:shadow-lg transition-all">
                  <div className="flex items-center space-x-2 text-gray-500 text-sm mb-2">
                    <Briefcase className="w-4 h-4" />
                    <span className="font-mono">{exp.duration}</span>
                  </div>
                  <h3 className="text-xl font-bold text-black font-heading">{exp.title}</h3>
                  <p className="text-gray-600 mb-2 font-medium">{exp.company}</p>
                  <p className="text-gray-500 mb-4 leading-relaxed">{exp.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill) => (
                      <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              {/* Timeline Dot */}
              <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-black rounded-full transform -translate-x-1/2 border-4 border-gray-50" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Contact Section
const ContactSection = () => {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-extrabold text-black mb-4 font-heading tracking-tight">Get In Touch</h2>
          <div className="w-24 h-1 bg-black mx-auto rounded-full" />
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto leading-relaxed">
            I'm actively looking for opportunities. Feel free to reach out for collaborations or just a friendly chat!
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <a 
              href="mailto:satyam.medya33@gmail.com"
              className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-black transition-colors group"
            >
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm uppercase tracking-wider font-medium">Email</p>
                <p className="text-black font-semibold">satyam.medya33@gmail.com</p>
              </div>
            </a>

            <a 
              href="tel:+917033673468"
              className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-black transition-colors group"
            >
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm uppercase tracking-wider font-medium">Phone</p>
                <p className="text-black font-semibold font-mono">+91 7033673468</p>
              </div>
            </a>

            <a 
              href="https://www.linkedin.com/in/satyam-medya-2b2825370"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-black transition-colors group"
            >
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Linkedin className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm uppercase tracking-wider font-medium">LinkedIn</p>
                <p className="text-black font-semibold">linkedin.com/in/satyam-medya-2b2825370</p>
              </div>
            </a>

            <a 
              href="https://github.com/Satyammedya33"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-black transition-colors group"
            >
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Github className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-gray-500 text-sm uppercase tracking-wider font-medium">GitHub</p>
                <p className="text-black font-semibold">github.com/Satyammedya33</p>
              </div>
            </a>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              window.location.href = 'mailto:satyam.medya33@gmail.com';
            }}
          >
            <input
              type="text"
              placeholder="Your Name"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-black placeholder-gray-400 focus:outline-none focus:border-black transition-colors"
            />
            <input
              type="email"
              placeholder="Your Email"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-black placeholder-gray-400 focus:outline-none focus:border-black transition-colors"
            />
            <textarea
              rows={4}
              placeholder="Your Message"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-black placeholder-gray-400 focus:outline-none focus:border-black transition-colors resize-none"
            />
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full py-4 bg-black rounded-xl text-white font-semibold shadow-lg hover:bg-gray-800 transition-colors flex items-center justify-center space-x-2 tracking-wide"
            >
              <span>Send Message</span>
              <ChevronRight className="w-5 h-5" />
            </motion.button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

// Dashboard Modal
const DashboardModal = ({ isOpen, onClose, stats }: { isOpen: boolean; onClose: () => void; stats: ReturnType<typeof useDashboardStats> }) => {
  if (!isOpen) return null;

  const maxDaily = Math.max(...stats.dailyData, 1);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-3xl p-6 md:p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-black font-heading tracking-tight">Analytics Dashboard</h2>
              <p className="text-gray-500">Real-time portfolio statistics</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <X className="w-6 h-6 text-gray-500" />
            </button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
              <Eye className="w-8 h-8 text-blue-600 mb-2" />
              <p className="text-2xl font-extrabold text-black font-heading tabular-nums">{stats.totalViews.toLocaleString()}</p>
              <p className="text-gray-500 text-sm uppercase tracking-wider">Total Views</p>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
              <Users className="w-8 h-8 text-green-600 mb-2" />
              <p className="text-2xl font-extrabold text-black font-heading tabular-nums">{stats.uniqueVisitors.toLocaleString()}</p>
              <p className="text-gray-500 text-sm uppercase tracking-wider">Unique Days</p>
            </div>
            <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4">
              <Activity className="w-8 h-8 text-purple-600 mb-2" />
              <p className="text-2xl font-extrabold text-black font-heading tabular-nums">{stats.avgTimeSpent}</p>
              <p className="text-gray-500 text-sm uppercase tracking-wider">Avg. Time</p>
            </div>
            <div className="bg-pink-50 border border-pink-200 rounded-2xl p-4">
              <TrendingUp className="w-8 h-8 text-pink-600 mb-2" />
              <p className="text-2xl font-extrabold text-black font-heading tabular-nums">+{stats.weeklyGrowth}%</p>
              <p className="text-gray-500 text-sm uppercase tracking-wider">Weekly Growth</p>
            </div>
          </div>

          {/* Traffic Chart */}
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200 mb-8">
            <h3 className="text-lg font-bold text-black mb-4 flex items-center space-x-2 font-heading">
              <LineChart className="w-5 h-5 text-blue-600" />
              <span>Traffic Overview (Last 7 Days)</span>
            </h3>
            <div className="flex items-end justify-between h-40 gap-2">
              {stats.dailyData.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ height: 0 }}
                  animate={{ height: `${(value / maxDaily) * 100}%` }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  className="flex-1 bg-gradient-to-t from-black to-gray-600 rounded-t-lg relative group min-h-[4px]"
                >
                  <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-black px-2 py-1 rounded text-xs text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap font-mono">
                    {value} views
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-gray-500 text-sm font-medium">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
                <span key={day}>{day}</span>
              ))}
            </div>
          </div>

          {/* Top Countries & SEO Tips */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-black mb-4 flex items-center space-x-2 font-heading">
                <Globe className="w-5 h-5 text-green-600" />
                <span>Top Regions</span>
              </h3>
              <div className="space-y-3">
                {stats.topCountries.map((country) => (
                  <div key={country.name} className="flex items-center justify-between">
                    <span className="text-gray-700 font-medium">{country.name}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-black rounded-full"
                          style={{ width: `${country.percent}%` }}
                        />
                      </div>
                      <span className="text-gray-500 text-sm font-mono">{country.percent}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-black mb-4 flex items-center space-x-2 font-heading">
                <Target className="w-5 h-5 text-pink-600" />
                <span>Reach Tips</span>
              </h3>
              <ul className="space-y-3 text-gray-700 text-sm">
                <li className="flex items-start space-x-2">
                  <span className="text-green-600">✓</span>
                  <span>Portfolio indexed by search engines</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-green-600">✓</span>
                  <span>Meta tags optimized for recruiters</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-green-600">✓</span>
                  <span>Share on LinkedIn for max visibility</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600">→</span>
                  <span>Add to GitHub profile README</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-600">→</span>
                  <span>Include in job applications</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="py-8 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center">
              <span className="text-black font-bold text-lg font-heading tracking-tight">SM</span>
            </div>
            <span className="text-gray-400">© 2024 Satyam Medya. All rights reserved.</span>
          </div>
          <div className="flex items-center space-x-6">
            <a href="https://github.com/Satyammedya33" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Github className="w-5 h-5" />
            </a>
            <a href="https://www.linkedin.com/in/satyam-medya-2b2825370" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin className="w-5 h-5" />
            </a>
            <a href="mailto:satyam.medya33@gmail.com" className="text-gray-400 hover:text-white transition-colors">
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// Main App Component
export function App() {
  const { count } = useVisitorCount();
  const stats = useDashboardStats();
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white cursor-none">
      <style>{`
        /* Professional Font Classes */
        .font-heading { font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif; }
        .font-body { font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', 'Fira Code', monospace; }
        .font-accent { font-family: 'Playfair Display', Georgia, serif; }
        
        body {
          font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
          text-rendering: optimizeLegibility;
        }
        
        h1, h2, h3, h4, h5, h6 {
          font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        * { cursor: none !important; }
        html { scroll-behavior: smooth; }
        
        /* Sleek Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #fafafa; }
        ::-webkit-scrollbar-thumb { background: #1a1a1a; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #333; }
        
        /* Tabular nums for numbers */
        .tabular-nums { font-variant-numeric: tabular-nums; }
      `}</style>
      
      <CustomCursor />
      <Navbar visitorCount={count} onDashboardClick={() => setIsDashboardOpen(true)} />
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <ProjectsSection />
      <ExperienceSection />
      <ContactSection />
      <Footer />
      
      <DashboardModal 
        isOpen={isDashboardOpen} 
        onClose={() => setIsDashboardOpen(false)} 
        stats={stats}
      />
    </div>
  );
}
